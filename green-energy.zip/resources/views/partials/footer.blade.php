    <!-- Start Footer Section -->
    <section class="footer-area">
        <div class="container">
            <div class="row">

                <div class="col-lg-6 col-md-6 footer-box-item">
                    <div class="footer-about footer-list">
                        <a class="footer-logo" href="{{ url('/') }}" aria-label="Green Energy Cornwall Ltd">
                            <img src="assets/img/logo.png" class="white-logo" alt="Green Energy Cornwall Ltd logo">
                        </a>
                        <p>
                            Green Energy Cornwall Ltd is a UK-registered renewable energy company focused on delivering
                            practical solutions solar PV, battery storage, energy audits, and sustainability support
                            designed for long-term value.
                        </p>

                    </div>
                </div>
                <div class="col-lg-3 col-md-6 footer-box-item">
                    <div class="footer-list">
                        <h5 class="title">Quick Links</h5>
                        <ul class="footer-nav-links">
                            <li><a href="about.html">About</a></li>
                            <li><a href="{{ '/services' }}">Services</a></li>
                            <li><a href="projects.html">Projects</a></li>
                            <li><a href="{{ '/contact' }}">Contact</a></li>
                        </ul>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 footer-box-item">
                    <div class="footer-list">
                        <h5 class="title">Contact Info</h5>
                        <div class="footer-contact-info">
                            <ul class="footer-contact-list">
                                <li><i class="fa fa-location-dot"></i> C/O SRS Direct, Corporation House, Corporation
                                    Rd., Swansea, UK, SA4 6SD</li>
                                <li><i class="fa fa-envelope"></i> <a
                                        href="mailto:info@greenenerycl.com">info@greenenerycl.com</a></li>
                                <li><i class="fa fa-globe"></i> <a href="https://greenenerycl.com" target="_blank"
                                        rel="noopener">greenenerycl.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End Footer Section -->

    <!-- Start Footer Copyright Section -->
    <div class="copyright-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <p>© <span id="year"></span> Green Energy Cornwall Ltd. All Rights Reserved.</p>
                </div>
                <div class="col-lg-6 col-md-6">
                    <ul>
                        <li><a href="terms-condition.html">Terms & Conditions</a></li>
                        <li><a href="privacy-policy.html">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Copyright Section -->
