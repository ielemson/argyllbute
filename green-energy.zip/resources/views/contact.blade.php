<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Primary SEO -->
    <title>Contact Us | Green Energy Cornwall Ltd</title>
    <meta name="description"
        content="Contact Green Energy Cornwall Ltd for solar PV, battery storage, energy audits, and renewable energy project support across the UK.">
    <meta name="keywords"
        content="Green Energy Cornwall Ltd, contact, renewable energy UK, solar PV, battery storage, energy audit, sustainability consulting">
    <meta name="author" content="Green Energy Cornwall Ltd">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://greenenerycl.com/contact">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Open Graph -->
    <meta property="og:title" content="Contact Us | Green Energy Cornwall Ltd">
    <meta property="og:description"
        content="Reach out for renewable energy consultations, project enquiries, and partnerships.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://greenenerycl.com/contact">
    <meta property="og:image" content="assets/img/og/greenenerycl-og.jpg">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Contact Us | Green Energy Cornwall Ltd">
    <meta name="twitter:description" content="Solar, storage, audits, and clean energy delivery support across the UK.">
    <meta name="twitter:image" content="assets/img/og/greenenerycl-og.jpg">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Mukta:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <!-- Bootstrap Min CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!-- Font Awesome Min CSS -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Bootstrap Icon CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    <!-- Mean Menu CSS -->
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <!-- Magnific Popup Min CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Swiper Min CSS -->
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <!-- Owl Carousel Min CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body>

    <!-- Start Preloader Section -->
    <div class="preloader">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="lds-spinner">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader Section -->

    <!-- Start Navbar Section -->
    @include('partials.navbar')
    <!-- End Navbar Section -->

    <!-- Start Page Title Section -->
    <div class="page-title-area">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content wow fadeInUp" data-wow-delay="0.10s">
                        <h2>Contact Us</h2>
                        <ul>
                            <li><a href="{{ url('/') }}">Home</a></li>
                            <li>Contact</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Section -->

    <!-- Start Contact Section -->
    <div class="contact-section contact-page-form section-padding">
        <div class="container">
            <div class="row">

                <!-- Left: Contact Info -->
                <div class="col-lg-4 col-md-12">
                    <div class="contact-information-box-1 wow fadeInLeft" data-wow-delay="0.10s">
                        <div class="row">

                            <div class="col-lg-12 col-md-12">
                                <div class="single-contact-info-box">
                                    <div class="contact-info">
                                        <h6>Registered Office:</h6>
                                        <p>C/O SRS Direct, Corporation House</p>
                                        <p>Corporation Road, Swansea</p>
                                        <p>United Kingdom, SA4 6SD</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="single-contact-info-box">
                                    <div class="contact-info">
                                        <h6>Phone:</h6>
                                        <p><a href="tel:+447549307273">+447549307273</a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="single-contact-info-box">
                                    <div class="contact-info">
                                        <h6>Email:</h6>
                                        <p><a href="mailto:info@greenenerycl.com">info@greenenerycl.com</a></p>
                                        {{-- <p><a href="mailto:support@greenenerycl.com">support@greenenerycl.com</a></p> --}}
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="single-contact-info-box">
                                    <div class="contact-info">
                                        <h6>Website:</h6>
                                        <p><a href="https://greenenerycl.com" target="_blank"
                                                rel="noopener">www.greenenerycl.com</a></p>
                                        <p>Company No. 14208450 (UK)</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="single-contact-info-box">
                                    <div class="contact-info">
                                        <h6>Business Hours:</h6>
                                        <p>Monday – Friday: 9:00am – 5:00pm</p>
                                        <p>We respond to enquiries as quickly as possible.</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- Right: Form -->
                <div class="col-lg-8 col-md-12">
                    <div class="contact-form contact-form-1 wow fadeInRight" data-wow-delay="0.10s">
                        <div class="mb-4">
                            <h3>Send Us a Message</h3>
                            <p>
                                Complete the form below and tell us what you need. Please include your location and the
                                type of service you’re interested in (e.g., solar PV, storage, energy audit, retrofit
                                planning).
                            </p>
                        </div>

                        <!-- Session Alerts -->
                        @if (session('success'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('success') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        @endif

                        @if (session('error'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                {{ session('error') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        @endif

                        @if ($errors->any())
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>Please fix the errors below.</strong>
                                <ul class="mb-0 mt-2">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        @endif

                        <!-- Optional status area (Parsley messages) -->
                        <p id="contact-status" class="mt-3 mb-0"></p>

                        <form id="contact-form" method="POST" action="{{ url('/contact/send') }}"
                            data-parsley-validate novalidate>
                            @csrf

                            <div class="row">
                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <input type="text" name="name" id="name" class="form-control"
                                            required data-parsley-minlength="2" data-parsley-maxlength="120"
                                            placeholder="Full Name" value="{{ old('name') }}">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <input type="email" name="email" id="email" class="form-control"
                                            required data-parsley-type="email" data-parsley-maxlength="190"
                                            placeholder="Email Address" value="{{ old('email') }}">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <input type="text" name="phone" id="phone" class="form-control"
                                            data-parsley-maxlength="30" placeholder="Phone (Optional)"
                                            value="{{ old('phone') }}">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <input type="text" name="subject" id="subject" class="form-control"
                                            required data-parsley-minlength="3" data-parsley-maxlength="160"
                                            placeholder="Subject" value="{{ old('subject') }}">
                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-12">
                                    <div class="form-group">
                                        <textarea name="message_body" id="message" class="form-control" rows="6" required
                                            data-parsley-minlength="10" data-parsley-maxlength="5000" placeholder="Tell us about your project…">{{ old('message') }}</textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-12">
                                    <button id="contact-submit" type="submit" class="default-btn">
                                        Send Message <span></span>
                                    </button>
                                    <p class="mt-3 mb-0">
                                        By submitting this form, you agree that we may contact you regarding your
                                        enquiry.
                                    </p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Contact Section -->

    <!-- Start Map Section -->
    <div class="map-area wow fadeInUp" data-wow-delay="0.10s">
        <div class="map-content">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2474.7042862263174!2d-4.068603824432332!3d51.66525039916097!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x486ef3b01d595e5d%3A0xf6fbf8b46346cddb!2sSRS%20Direct!5e0!3m2!1sen!2sng!4v1770740526011!5m2!1sen!2sng"
                width="100%" height="450" style="border:0;" allowfullscreen loading="lazy"
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>
    <!-- End Map Section -->

    @include('partials.footer')

    <!-- Start Go Top Section -->
    <div class="go-top">
        <i class="fas fa-chevron-up"></i>
        <i class="fas fa-chevron-up"></i>
    </div>
    <!-- End Go Top Section -->

    <!-- jQuery Min JS -->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap Min JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Mean Menu JS  -->
    <script src="assets/js/jquery.meanmenu.js"></script>
    <!-- Appear Min JS -->
    <script src="assets/js/jquery.appear.min.js"></script>
    <!-- CounterUp Min JS -->
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Owl Carousel Min JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Magnific Popup Min JS -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Swiper Min JS -->
    <script src="assets/js/swiper.min.js"></script>
    <!-- WOW Min JS -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Parsley (validation only) -->
    <script src="https://cdn.jsdelivr.net/npm/parsleyjs@2.9.2/dist/parsley.min.js"></script>

    <script>
        // keep year current
        (function() {
            var el = document.getElementById('year');
            if (el) el.textContent = new Date().getFullYear();
        })();

        // WOW init
        (function() {
            if (typeof WOW === 'function') {
                new WOW({
                    boxClass: 'wow',
                    animateClass: 'animated',
                    offset: 80,
                    mobile: true,
                    live: true
                }).init();
            }
        })();

        // Parsley config + manual submit (no ajax)
        $(function() {
            const $form = $('#contact-form');
            const $btn = $('#contact-submit');
            const $status = $('#contact-status');

            window.ParsleyConfig = {
                errorClass: 'is-invalid',
                successClass: 'is-valid',
                classHandler: function(field) {
                    return field.$element;
                },
                errorsContainer: function(field) {
                    return field.$element.closest('.form-group');
                },
                errorsWrapper: '<div class="invalid-feedback d-block"></div>',
                errorTemplate: '<div></div>'
            };

            const parsley = $form.parsley();

            function setStatus(msg, type) {
                if (!$status.length) return;
                $status.removeClass().addClass('alert alert-' + type + ' mt-3').text(msg);
            }

            function clearStatus() {
                if (!$status.length) return;
                $status.removeClass().text('');
            }

            $form.on('submit', function(e) {
                clearStatus();

                // block invalid submit
                if (!parsley.validate()) {
                    e.preventDefault();
                    setStatus('Please correct the highlighted fields and try again.', 'danger');
                    return;
                }

                // allow normal POST; prevent double click
                $btn.prop('disabled', true);
                setStatus('Sending your message…', 'info');
            });
        });
    </script>

</body>

</html>
