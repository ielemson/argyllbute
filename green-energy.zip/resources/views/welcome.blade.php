<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Primary SEO -->
    <title>Green Energy Cornwall Ltd | Solar, Storage & Energy Efficiency Solutions</title>
    <meta name="description"
        content="Green Energy Cornwall Ltd delivers practical renewable energy solutions across the UK—solar PV, battery storage, energy audits, and project development to cut costs and emissions." />
    <meta name="keywords"
        content="Green Energy Cornwall Ltd, solar installation UK, solar PV, battery storage, energy efficiency, renewable energy consulting, sustainability, clean energy" />
    <meta name="author" content="Green Energy Cornwall Ltd" />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="https://greenenerycl.com/" />

    <!-- Open Graph -->
    <meta property="og:title" content="Green Energy Cornwall Ltd | Renewable Energy Solutions" />
    <meta property="og:description"
        content="Solar PV, battery storage, energy efficiency consulting, and renewable project development—built for reliability, compliance, and long-term value." />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://greenenerycl.com/" />
    <meta property="og:image" content="assets/img/og/greenenerycl-og.jpg" />

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Green Energy Cornwall Ltd" />
    <meta name="twitter:description"
        content="Solar PV, storage, audits, and renewable project development—helping homes and businesses transition to clean energy." />
    <meta name="twitter:image" content="assets/img/og/greenenerycl-og.jpg" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Mukta:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <!-- Bootstrap Min CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!-- Font Awesome Min CSS -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Bootstrap Icon CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    <!-- Mean Menu CSS -->
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <!-- Magnific Popup Min CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Swiper Min CSS -->
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <!-- Owl Carousel Min CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body>

    <!-- Start Preloader Section -->
    <div class="preloader">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="lds-spinner">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader Section -->

    <!-- Start Navbar Section -->
    <div class="navbar-area">
        <div class="shipping-responsive-nav">
            <div class="container">
                <div class="shipping-responsive-menu">
                    <div class="logo">
                        <a href="{{ url('/') }}" aria-label="Green Energy Cornwall Ltd Home">
                            <img src="assets/img/logo.png" class="white-logo" alt="Green Energy Cornwall Ltd logo">
                            <img src="assets/img/logo-black.png" class="black-logo"
                                alt="Green Energy Cornwall Ltd logo">
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="shipping-nav">
            <div class="container">
                <nav class="navbar navbar-expand-md navbar-light">
                    <a class="navbar-brand" href="{{ url('/') }}" aria-label="Green Energy Cornwall Ltd Home">
                        <img src="assets/img/logo.png" class="white-logo" alt="Green Energy Cornwall Ltd logo">
                        <img src="assets/img/logo-black.png" class="black-logo" alt="Green Energy Cornwall Ltd logo">
                    </a>

                    <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="{{ url('/') }}" class="nav-link active">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ url('/about') }}" class="nav-link">About Us</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ url('/services') }}" class="nav-link">Services</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ url('/contact') }}" class="nav-link">Contact</a>
                            </li>
                        </ul>

                        <div class="other-option">
                            <a class="default-btn" href="{{ url('/contact') }}">Request a Consultation
                                <span></span></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- End Navbar Section -->

    <!-- Start Home Section (Hero) -->
    <div class="home-section">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-8 offset-lg-2 col-md-12">
                            <div class="main-banner-content">
                                <h3 class="wow fadeInUp" data-wow-delay="0.10s">Clean &amp; Reliable Energy</h3>

                                <h1 class="wow fadeInUp" data-wow-delay="0.25s">
                                    Powering Homes and Businesses Sustainably
                                </h1>

                                <p class="wow fadeInUp" data-wow-delay="0.40s">
                                    Solar PV, battery storage, and energy efficiency solutions built for long-term
                                    value.
                                </p>

                                <div class="banner-btn wow fadeInUp" data-wow-delay="0.55s">
                                    <a href="{{ url('/services') }}" class="default-btn-one">Our Services
                                        <span></span></a>
                                    <a href="{{ url('/contact') }}" class="default-btn">Contact Us <span></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Home Section -->

    <!-- Start Features Section -->
    <section class="features-section bg-grey pt-100 pb-70">
        <div class="container">
            <div class="row g-0">
                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item wow fadeInUp" data-wow-delay="0.10s">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-1.svg" alt="features icon">
                        </div>
                        <h3>Lower Energy Costs</h3>
                        <p>Reduce bills with efficient renewable systems tailored to your usage and goals.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item bg-active wow fadeInUp" data-wow-delay="0.20s">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-2.svg" alt="features icon">
                        </div>
                        <h3>Scalable Solutions</h3>
                        <p>From homes to commercial sites—systems designed to grow with your energy needs.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item wow fadeInUp" data-wow-delay="0.30s">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-3.svg" alt="features icon">
                        </div>
                        <h3>Compliance &amp; Safety</h3>
                        <p>We prioritise standards, documentation, and safe installation practices from start to finish.
                        </p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item bg-active wow fadeInUp" data-wow-delay="0.40s">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-4.svg" alt="features icon">
                        </div>
                        <h3>Expert Support</h3>
                        <p>Clear guidance, maintenance planning, and after-service support you can rely on.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Features Section -->

    <!-- Start About Section -->
    <section class="about-section section-padding">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="about-content wow fadeInLeft" data-wow-delay="0.10s">
                        <h6 class="sub-title">Clean Energy. Practical Delivery.</h6>
                        <h2>Helping You Transition to Renewable Power</h2>
                        <p>
                            Green Energy Cornwall Ltd is a UK-registered renewable energy company committed to
                            delivering
                            sustainable, efficient, and affordable energy solutions.
                        </p>
                        <p>
                            Our work supports households, businesses, and communities as they move to cleaner energy
                            systems that
                            reduce costs, cut emissions, and strengthen long term energy resilience.
                        </p>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="about-image wow fadeInRight" data-wow-delay="0.15s">
                        <img src="{{ asset('assets/img/about.jpg') }}" alt="Renewable energy installation">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End About Section -->

    <!-- Start Services Section -->
    <section class="services-section bg-grey pt-100 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title wow fadeInUp" data-wow-delay="0.10s">
                        <h6>What We Do</h6>
                        <h2>Renewable Energy Services</h2>
                        <p class="mt-2">
                            End-to-end support—from assessment and design to installation, optimisation, and ongoing
                            guidance.
                        </p>
                    </div>
                </div>

                <!-- 1 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.10s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-1.svg" alt="svg icon">
                        </div>
                        <h3>Solar Energy Solutions</h3>
                        <p>Design, installation, and maintenance of solar PV systems for homes and businesses.</p>
                        <div class="services-btn">
                            <a href="{{ '/services' }}" class="read-more"><i class="bi bi-arrow-right-short"></i>
                                Learn More</a>
                        </div>
                    </div>
                </div>

                <!-- 2 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.20s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-2.svg" alt="svg icon">
                        </div>
                        <h3>Battery Storage Systems</h3>
                        <p>Increase reliability and maximise renewable usage with modern battery storage deployment.</p>
                        <div class="services-btn">
                            <a href="{{ '/services' }}" class="read-more"><i class="bi bi-arrow-right-short"></i>
                                Learn More</a>
                        </div>
                    </div>
                </div>

                <!-- 3 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.30s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-3.svg" alt="svg icon">
                        </div>
                        <h3>Energy Efficiency Consulting</h3>
                        <p>Energy audits and practical recommendations to reduce consumption and operational costs.</p>
                        <div class="services-btn">
                            <a href="{{ '/services' }}" class="read-more"><i class="bi bi-arrow-right-short"></i>
                                Learn More</a>
                        </div>
                    </div>
                </div>

                <!-- 4 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.40s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-4.svg" alt="svg icon">
                        </div>
                        <h3>Renewable Project Development</h3>
                        <p>Planning and delivery support for small-scale and community renewable energy projects.</p>
                        <div class="services-btn">
                            <a href="{{ '/services' }}" class="read-more"><i class="bi bi-arrow-right-short"></i>
                                Learn More</a>
                        </div>
                    </div>
                </div>

                <!-- 5 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.50s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-7.svg" alt="svg icon">
                        </div>
                        <h3>Green Energy Advisory &amp; Compliance</h3>
                        <p>Guidance on regulations, incentives, documentation, and sustainability reporting.</p>
                        <div class="services-btn">
                            <a href="{{ '/services' }}" class="read-more"><i class="bi bi-arrow-right-short"></i>
                                Learn More</a>
                        </div>
                    </div>
                </div>

                <!-- 6 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.60s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-6.svg" alt="svg icon">
                        </div>
                        <h3>Operations &amp; Maintenance Planning</h3>
                        <p>Proactive maintenance scheduling and performance checks to protect your investment.</p>
                        <div class="services-btn">
                            <a href="{{ '/contact' }}" class="read-more"><i class="bi bi-arrow-right-short"></i>
                                Speak to Us</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End Services Section -->

    <!-- Start Skill Section -->
    <section class="skill-area section-padding">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="skill-content wow fadeInLeft" data-wow-delay="0.10s">
                        <h6 class="sub-title">Why Choose Us</h6>
                        <h2>Delivering a Brighter Future</h2>
                        <p>
                            We focus on reliability, transparency, and long-term performance so your clean energy system
                            continues to deliver measurable value.
                        </p>

                        <div class="skills">
                            <div class="skill-item wow fadeInUp" data-wow-delay="0.15s">
                                <h4>Project Planning &amp; Delivery <em>95%</em></h4>
                                <div class="skill-progress">
                                    <div class="progres" data-value="95%"></div>
                                </div>
                            </div>

                            <div class="skill-item wow fadeInUp" data-wow-delay="0.25s">
                                <h4>Safety &amp; Compliance <em>97%</em></h4>
                                <div class="skill-progress">
                                    <div class="progres" data-value="97%"></div>
                                </div>
                            </div>

                            <div class="skill-item wow fadeInUp" data-wow-delay="0.35s">
                                <h4>System Performance Optimisation <em>94%</em></h4>
                                <div class="skill-progress">
                                    <div class="progres" data-value="94%"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="skill-image wow fadeInRight" data-wow-delay="0.15s">
                        <img src="assets/img/skill.jpg" alt="Solar panels and clean energy infrastructure">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Skill Section -->

    <!-- Start Hire Section (CTA) -->
    <section class="hire-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-12">
                    <div class="hire-content wow zoomIn" data-wow-delay="0.10s">
                        <h2>Ready to Cut Costs and Go Clean?</h2>
                        <p>
                            Speak with Green Energy Cornwall Ltd to explore solar PV, battery storage, and energy
                            efficiency options
                            tailored to your home or business.
                        </p>
                        <div class="hire-btn wow fadeInUp" data-wow-delay="0.20s">
                            <a class="default-btn-one" href="{{ url('/contact') }}">Contact Us <span></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Hire Section -->

    @include('partials.footer')

    <!-- Start Go Top Section -->
    <div class="go-top">
        <i class="fas fa-chevron-up"></i>
        <i class="fas fa-chevron-up"></i>
    </div>
    <!-- End Go Top Section -->

    <!-- jQuery Min JS -->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap Min JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Mean Menu JS  -->
    <script src="assets/js/jquery.meanmenu.js"></script>
    <!-- Appear Min JS -->
    <script src="assets/js/jquery.appear.min.js"></script>
    <!-- CounterUp Min JS -->
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Owl Carousel Min JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Magnific Popup Min JS -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Swiper Min JS -->
    <script src="assets/js/swiper.min.js"></script>
    <!-- WOW Min JS -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- WOW init -->
    <script>
        (function() {
            if (typeof WOW === 'function') {
                new WOW({
                    boxClass: 'wow',
                    animateClass: 'animated',
                    offset: 80,
                    mobile: true,
                    live: true
                }).init();
            }
        })();
    </script>

    <!-- Small helper to keep year current -->
    <script>
        (function() {
            var el = document.getElementById('year');
            if (el) el.textContent = new Date().getFullYear();
        })();
    </script>

</body>


</html>
