<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Primary SEO -->
    <title>Services | Green Energy Cornwall Ltd</title>
    <meta name="description"
        content="Explore our renewable energy services: solar PV, battery storage, energy audits, efficiency upgrades, and project advisory across the UK.">
    <meta name="keywords"
        content="Green Energy Cornwall Ltd services, solar PV, battery storage, energy audit, energy efficiency, renewable energy UK, sustainability consulting">
    <meta name="author" content="Green Energy Cornwall Ltd">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://greenenerycl.com/services">

    <!-- Open Graph -->
    <meta property="og:title" content="Services | Green Energy Cornwall Ltd">
    <meta property="og:description"
        content="Solar PV, battery storage, energy audits, efficiency upgrades, and clean energy project support.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://greenenerycl.com/services">
    <meta property="og:image" content="assets/img/og/greenenerycl-og.jpg">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Mukta:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <!-- Bootstrap Min CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!-- Font Awesome Min CSS -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Bootstrap Icon CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    <!-- Mean Menu CSS -->
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <!-- Magnific Popup Min CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Swiper Min CSS -->
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <!-- Owl Carousel Min CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body>

    <!-- Start Preloader Section -->
    <div class="preloader">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="lds-spinner">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader Section -->

    <!-- Start Navbar Section -->
    <div class="navbar-area">
        <div class="shipping-responsive-nav">
            <div class="container">
                <div class="shipping-responsive-menu">
                    <div class="logo">
                        <a href="{{ url('/') }}" aria-label="Green Energy Cornwall Ltd Home">
                            <img src="assets/img/logo.png" class="white-logo" alt="Green Energy Cornwall Ltd logo">
                            <img src="assets/img/logo-black.png" class="black-logo"
                                alt="Green Energy Cornwall Ltd logo">
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="shipping-nav">
            <div class="container">
                <nav class="navbar navbar-expand-md navbar-light">
                    <a class="navbar-brand" href="{{ url('/') }}" aria-label="Green Energy Cornwall Ltd Home">
                        <img src="assets/img/logo.png" class="white-logo" alt="Green Energy Cornwall Ltd logo">
                        <img src="assets/img/logo-black.png" class="black-logo" alt="Green Energy Cornwall Ltd logo">
                    </a>

                    <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="{{ url('/') }}" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ url('/about') }}" class="nav-link">About Us</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ url('/services') }}" class="nav-link active">Services</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ url('/contact') }}" class="nav-link">Contact</a>
                            </li>
                        </ul>

                        <div class="other-option">
                            <a class="default-btn" href="{{ url('/contact') }}">Request a Quote <span></span></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- End Navbar Section -->

    <!-- Start Page Title Section -->
    <div class="page-title-area">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content wow fadeInUp" data-wow-delay="0.1s">
                        <h2>Services</h2>
                        <ul>
                            <li><a href="{{ url('/') }}">Home</a></li>
                            <li>Services</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Section -->

    <!-- Start Services Section -->
    <section class="services-section pt-100 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title wow fadeInUp" data-wow-delay="0.1s">
                        <h6>What We Provide</h6>
                        <h2>Our Services</h2>
                        <p class="mt-3">
                            From system design to delivery support, we help you adopt clean energy confidently whether
                            you are upgrading a home, powering a business, or planning a larger project.
                        </p>
                    </div>
                </div>

                <!-- Service 1 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.1s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-1.svg" alt="Solar PV icon">
                        </div>
                        <h3>Solar PV Solutions</h3>
                        <p>
                            End-to-end solar support from assessment and sizing to system design built to maximise
                            output and long-term savings.
                        </p>
                        <div class="services-btn">
                            <a href="{{ url('/contact') }}" class="read-more">
                                <i class="bi bi-arrow-right-short"></i> Get Started
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Service 2 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.2s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-2.svg" alt="Battery storage icon">
                        </div>
                        <h3>Battery Storage</h3>
                        <p>
                            Store excess power, reduce grid reliance, and improve resilience with storage options
                            matched to your energy usage.
                        </p>
                        <div class="services-btn">
                            <a href="{{ url('/contact') }}" class="read-more">
                                <i class="bi bi-arrow-right-short"></i> Talk to Us
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Service 3 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.3s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-3.svg" alt="Energy audit icon">
                        </div>
                        <h3>Energy Audits & Assessments</h3>
                        <p>
                            Understand where energy is being wasted and what to fix first, with clear recommendations
                            and prioritised actions.
                        </p>
                        <div class="services-btn">
                            <a href="{{ url('/contact') }}" class="read-more">
                                <i class="bi bi-arrow-right-short"></i> Book an Audit
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Service 4 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.4s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-4.svg" alt="Efficiency upgrades icon">
                        </div>
                        <h3>Efficiency Upgrades</h3>
                        <p>
                            Practical upgrades that cut costs lighting optimisation, load management, and efficiency
                            planning for homes and businesses.
                        </p>
                        <div class="services-btn">
                            <a href="{{ url('/contact') }}" class="read-more">
                                <i class="bi bi-arrow-right-short"></i> Request Advice
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Service 5 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.5s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-7.svg" alt="Project support icon">
                        </div>
                        <h3>Project & Sustainability Advisory</h3>
                        <p>
                            Support for feasibility, budgeting, documentation, and delivery planning helping you move
                            from idea to execution.
                        </p>
                        <div class="services-btn">
                            <a href="{{ url('/contact') }}" class="read-more">
                                <i class="bi bi-arrow-right-short"></i> Speak with Us
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Service 6 -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-services-item wow fadeInUp" data-wow-delay="0.6s">
                        <div class="services-icon">
                            <img src="assets/img/icons/services-icon-6.svg" alt="Monitoring icon">
                        </div>
                        <h3>Monitoring & Optimisation</h3>
                        <p>
                            Keep systems performing at their best with performance tracking, optimisation guidance, and
                            practical aftercare support.
                        </p>
                        <div class="services-btn">
                            <a href="{{ url('/contact') }}" class="read-more">
                                <i class="bi bi-arrow-right-short"></i> Learn More
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End Services Section -->

    <!-- Start Hire Section -->
    <section class="hire-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-12">
                    <div class="hire-content wow zoomIn" data-wow-delay="0.1s">
                        <h2>Ready to Start Your Clean Energy Journey?</h2>
                        <p>
                            Tell us about your goals and location we’ll respond with practical options and clear next
                            steps.
                        </p>
                        <div class="hire-btn">
                            <a class="default-btn-one" href="{{ url('/contact') }}">Contact Us <span></span></a>
                            <a class="default-btn" href="{{ url('/services') }}">View Services <span></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Hire Section -->

    <!-- Start Services Section Two -->
    <section class="services-section-two pt-100 pb-70">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <div class="section-title wow fadeInUp" data-wow-delay="0.1s">
                        <h6>Featured</h6>
                        <h2>Service Highlights</h2>
                        <p class="mt-3">
                            A quick look at key areas we support ideal if you’re comparing options or planning your next
                            step.
                        </p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-services-two wow fadeInUp" data-wow-delay="0.1s">
                        <div class="services-two-img">
                            <img src="assets/img/services/service-1.jpg" alt="Solar PV service image">
                        </div>
                        <div class="services-two-info">
                            <h3>Solar PV</h3>
                            <p>Design-led solar solutions built to deliver measurable savings and consistent
                                performance.</p>
                            <div class="services-btn">
                                <a href="{{ url('/contact') }}" class="read-more"><i
                                        class="bi bi-arrow-right-short"></i> Enquire</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-services-two wow fadeInUp" data-wow-delay="0.2s">
                        <div class="services-two-img">
                            <img src="assets/img/services/service-2.jpg" alt="Battery storage service image">
                        </div>
                        <div class="services-two-info">
                            <h3>Battery Storage</h3>
                            <p>Smarter storage planning to increase self-consumption and reduce peak energy costs.</p>
                            <div class="services-btn">
                                <a href="{{ url('/contact') }}" class="read-more"><i
                                        class="bi bi-arrow-right-short"></i> Enquire</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-services-two wow fadeInUp" data-wow-delay="0.3s">
                        <div class="services-two-img">
                            <img src="assets/img/services/service-3.jpg" alt="Energy audit service image">
                        </div>
                        <div class="services-two-info">
                            <h3>Energy Audits</h3>
                            <p>Actionable audits that show where energy is lost and what improvements matter most.</p>
                            <div class="services-btn">
                                <a href="{{ url('/contact') }}" class="read-more"><i
                                        class="bi bi-arrow-right-short"></i> Enquire</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-services-two wow fadeInUp" data-wow-delay="0.4s">
                        <div class="services-two-img">
                            <img src="assets/img/services/service-4.jpg" alt="Efficiency upgrades service image">
                        </div>
                        <div class="services-two-info">
                            <h3>Efficiency Upgrades</h3>
                            <p>Cost-saving upgrades and planning that reduce consumption without disrupting operations.
                            </p>
                            <div class="services-btn">
                                <a href="{{ url('/contact') }}" class="read-more"><i
                                        class="bi bi-arrow-right-short"></i> Enquire</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-services-two wow fadeInUp" data-wow-delay="0.5s">
                        <div class="services-two-img">
                            <img src="assets/img/services/service-5.jpg" alt="Sustainability advisory service image">
                        </div>
                        <div class="services-two-info">
                            <h3>Advisory</h3>
                            <p>Feasibility, documentation, and delivery planning to keep projects compliant and
                                bankable.</p>
                            <div class="services-btn">
                                <a href="{{ url('/contact') }}" class="read-more"><i
                                        class="bi bi-arrow-right-short"></i> Enquire</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-services-two wow fadeInUp" data-wow-delay="0.6s">
                        <div class="services-two-img">
                            <img src="assets/img/services/service-6.jpg"
                                alt="Monitoring and optimisation service image">
                        </div>
                        <div class="services-two-info">
                            <h3>Monitoring</h3>
                            <p>Performance tracking and optimisation guidance to protect your investment over time.</p>
                            <div class="services-btn">
                                <a href="{{ url('/contact') }}" class="read-more"><i
                                        class="bi bi-arrow-right-short"></i> Enquire</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End Services Section Two -->

    <!-- Footer -->
    @include('partials.footer')

    <!-- Go Top -->
    <div class="go-top">
        <i class="fas fa-chevron-up"></i>
        <i class="fas fa-chevron-up"></i>
    </div>

    <!-- JS -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.meanmenu.js"></script>
    <script src="assets/js/jquery.appear.min.js"></script>
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/main.js"></script>

    <!-- Keep year current -->
    <script>
        (function() {
            var el = document.getElementById('year');
            if (el) el.textContent = new Date().getFullYear();
        })();
    </script>

    <!-- WOW init (animations) -->
    <script>
        (function() {
            if (typeof WOW === 'function') {
                new WOW({
                    boxClass: 'wow',
                    animateClass: 'animated',
                    offset: 80,
                    mobile: true,
                    live: true
                }).init();
            }
        })();
    </script>

</body>


</html>
