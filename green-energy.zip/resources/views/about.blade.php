<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Primary SEO -->
    <title>About Us | Green Energy Cornwall Ltd</title>
    <meta name="description"
        content="Learn about Green Energy Cornwall Ltd—our mission, values, and approach to delivering reliable solar, battery storage, and energy efficiency solutions across the UK." />
    <meta name="keywords"
        content="About Green Energy Cornwall Ltd, renewable energy company UK, solar PV, battery storage, energy efficiency consulting, sustainability" />
    <meta name="author" content="Green Energy Cornwall Ltd" />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="https://greenenerycl.com/about" />

    <!-- Open Graph -->
    <meta property="og:title" content="About Us | Green Energy Cornwall Ltd" />
    <meta property="og:description"
        content="A UK-registered company delivering practical renewable energy solutions—solar PV, storage, audits, and project support." />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://greenenerycl.com/about" />
    <meta property="og:image" content="assets/img/og/greenenerycl-og.jpg" />

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="About Us | Green Energy Cornwall Ltd" />
    <meta name="twitter:description"
        content="Reliable renewable energy solutions with a compliance-first delivery approach across the UK." />
    <meta name="twitter:image" content="assets/img/og/greenenerycl-og.jpg" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Mukta:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <!-- Bootstrap Min CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!-- Font Awesome Min CSS -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Bootstrap Icon CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    <!-- Mean Menu CSS -->
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <!-- Magnific Popup Min CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Swiper Min CSS -->
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <!-- Owl Carousel Min CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body>

    <!-- Start Preloader Section -->
    <div class="preloader">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="lds-spinner">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader Section -->

    <!-- Start Navbar Section -->
    @include('partials.navbar')
    <!-- End Navbar Section -->

    <!-- Start Page Title Section -->
    <div class="page-title-area">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content">
                        <h2>About Us</h2>
                        <ul>
                            <li><a href="{{ url('/') }}">Home</a></li>
                            <li>About Us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Section -->

    <!-- Start Features Section -->
    <section class="features-section about-page bg-grey pt-100 pb-70">
        <div class="container">
            <div class="row g-0">

                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-1.svg" alt="feature icon">
                        </div>
                        <h3>Cost-Effective Energy</h3>
                        <p>Solutions designed to reduce bills while improving energy efficiency and resilience.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item bg-active">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-2.svg" alt="feature icon">
                        </div>
                        <h3>Scalable Delivery</h3>
                        <p>From residential to commercial systems tailored to your site, usage, and goals.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-3.svg" alt="feature icon">
                        </div>
                        <h3>Safety & Compliance</h3>
                        <p>We prioritise documentation, standards, and safe installation practices end-to-end.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="single-features-item bg-active">
                        <div class="features-icon">
                            <img src="assets/img/icons/features-icon-4.svg" alt="feature icon">
                        </div>
                        <h3>Reliable Support</h3>
                        <p>Clear guidance, maintenance planning, and after-service support you can count on.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End Features Section -->

    <!-- Start About Section -->
    <section class="about-section section-padding">
        <div class="container">
            <div class="row d-flex align-items-center">

                <div class="col-lg-6 col-md-12">
                    <div class="about-content">
                        <h6 class="sub-title">Clean Energy. Practical Delivery.</h6>
                        <h2>We Help Homes and Businesses Move to Renewable Power</h2>
                        <p>
                            Green Energy Cornwall Ltd is a UK-registered renewable energy company committed to
                            delivering sustainable,
                            efficient, and affordable energy solutions. We support households, businesses, and
                            communities in their
                            transition to cleaner energy systems that reduce costs, carbon footprints, and long-term
                            energy risks.
                        </p>
                        <p>
                            Our approach is simple: understand your needs, recommend practical options, and deliver
                            solutions built for
                            reliability and long-term performance.
                        </p>
                        <p>
                            Company status: Active • Company No. 14208450 • Registered office: Swansea, United Kingdom
                            (SA4 6SD).
                        </p>
                        <div class="mt-4">
                            <a class="default-btn-one" href="{{ '/services' }}">Explore Services <span></span></a>
                            <a class="default-btn" href="{{ '/contact' }}">Contact Us <span></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="about-image">
                        <img src="{{ asset('assets/img/about.jpg') }}" alt="Renewable energy project image">

                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End About Section -->

    <!-- Start About Section (Values / Approach) -->
    <section class="about-section pt-100 pb-100">
        <div class="container">
            <div class="row d-flex align-items-center">

                <div class="col-lg-6 col-md-12">
                    <div class="about-image about-image-2">
                        <img src="assets/img/about-2.jpg" alt="Solar and storage planning image">
                        <div class="waves-box">
                            <a href="https://www.youtube.com/watch?v=l73dA-A0Si4"
                                class="iq-video popup-video mfp-iframe" aria-label="Play video"> <i
                                    class="fa fa-play"></i></a>
                            <div class="iq-waves">
                                <div class="waves wave-1"></div>
                                <div class="waves wave-2"></div>
                                <div class="waves wave-3"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="about-content about-content-2">
                        <h6 class="sub-title">Our Approach</h6>
                        <h2>From Assessment to Aftercare Built for Long-Term Value</h2>
                        <p>
                            We focus on outcomes you can measure: reduced consumption, lower energy costs, and stronger
                            resilience.
                            Whether you’re planning solar PV, adding battery storage, or improving efficiency, we bring
                            clarity to the
                            process and keep delivery grounded in safe, compliant practice.
                        </p>
                        <p>
                            We work with trusted partners and qualified professionals to ensure installations meet
                            modern standards and
                            are set up for reliable performance over time.
                        </p>
                        <p>
                            If you’re unsure where to start, we can begin with a simple assessment and recommend the
                            best next step.
                        </p>
                        <div class="mt-4">
                            <a class="default-btn-one" href="{{ '/contact' }}">Request a Consultation
                                <span></span></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End About Section -->


    @include('partials.footer')
    <!-- Start Go Top Section -->
    <div class="go-top">
        <i class="fas fa-chevron-up"></i>
        <i class="fas fa-chevron-up"></i>
    </div>
    <!-- End Go Top Section -->

    <!-- jQuery Min JS -->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap Min JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Mean Menu JS  -->
    <script src="assets/js/jquery.meanmenu.js"></script>
    <!-- Appear Min JS -->
    <script src="assets/js/jquery.appear.min.js"></script>
    <!-- CounterUp Min JS -->
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Owl Carousel Min JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Magnific Popup Min JS -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Swiper Min JS -->
    <script src="assets/js/swiper.min.js"></script>
    <!-- WOW Min JS -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Keep year current -->
    <script>
        (function() {
            var el = document.getElementById('year');
            if (el) el.textContent = new Date().getFullYear();
        })();
    </script>

</body>

</html>
